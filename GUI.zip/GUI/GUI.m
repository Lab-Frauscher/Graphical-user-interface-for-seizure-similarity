classdef GUI < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                        matlab.ui.Figure
        GridLayout3                     matlab.ui.container.GridLayout
        SeizureBPanel                   matlab.ui.container.Panel
        GridLayout_2                    matlab.ui.container.GridLayout
        Image_2                         matlab.ui.control.Image
        Image2_2                        matlab.ui.control.Image
        Image3_2                        matlab.ui.control.Image
        Image4_2                        matlab.ui.control.Image
        Panel_2                         matlab.ui.container.Panel
        GridLayout2                     matlab.ui.container.GridLayout
        SeizuretimesSliderLabel         matlab.ui.control.Label
        SeizuretimesSlider              matlab.ui.control.Slider
        OnsetPatternTextAreaLabel       matlab.ui.control.Label
        OnsetPatternTextArea            matlab.ui.control.TextArea
        OnsetPatternTextArea_2Label     matlab.ui.control.Label
        OnsetPatternTextArea_2          matlab.ui.control.TextArea
        SeizureAPanel                   matlab.ui.container.Panel
        GridLayout                      matlab.ui.container.GridLayout
        Image                           matlab.ui.control.Image
        Image2                          matlab.ui.control.Image
        Image3                          matlab.ui.control.Image
        Image4                          matlab.ui.control.Image
        Panel_3                         matlab.ui.container.Panel
        GridLayout4                     matlab.ui.container.GridLayout
        SeizureDurationTextAreaLabel    matlab.ui.control.Label
        SeizureDurationTextArea         matlab.ui.control.TextArea
        SeizureDurationTextArea_2Label  matlab.ui.control.Label
        SeizureDurationTextArea_2       matlab.ui.control.TextArea
        SezireOnsetPatternTextArea_2    matlab.ui.control.TextArea
        PLOTButton                      matlab.ui.control.Button
        NEXTButton                      matlab.ui.control.Button
        AretheseizuressimilarButtonGroup  matlab.ui.container.ButtonGroup
        ChooseanoptionButton            matlab.ui.control.RadioButton
        SomewhatsimilarButton           matlab.ui.control.RadioButton
        VerysimilarButton               matlab.ui.control.RadioButton
        LowsimilarityButton             matlab.ui.control.RadioButton
        NotrealtedButton                matlab.ui.control.RadioButton
        UIAxes2                         matlab.ui.control.UIAxes
        UIAxes                          matlab.ui.control.UIAxes
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Value changed function: SeizuretimesSlider
        function SeizuretimesSliderValueChanged(app, event)

            % Define the path to the GUI's directory
            % This automatically retrieves the path based on the current file's location
            % path_GUI='D:\Project_2\Codes\Codes Final\';
            path_GUI = [fileparts(fileparts(mfilename('fullpath'))) '\']

            % Retrieve the current value of the slider and round it to the nearest integer
            slider_val = round(app.SeizuretimesSlider.Value);

            % Plot the initial time indicator for seizure A with white triangles
            plot_time = -1 * ones(1, 116);
            plot(app.UIAxes, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
            plot_time = nan(1, 116);
            plot_time(slider_val + 16) = -1;  % Update the position of the indicator based on the slider value
            plot(app.UIAxes, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

            % Plot the initial time indicator for seizure B with white triangles
            plot_time = -1 * ones(1, 116);
            plot(app.UIAxes2, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
            plot_time = nan(1, 116);
            plot_time(slider_val + 16) = -1;  % Update the position of the indicator based on the slider value
            plot(app.UIAxes2, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

            % Adjust the x-axis limits based on the current slider value
            if slider_val < 35
                % Set x-axis limits for lower slider values
                xlim(app.UIAxes, [-31 44]);
                xlim(app.UIAxes2, [-31 44]);
            else
                % Set x-axis limits for higher slider values
                xlim(app.UIAxes, [15 90]);
                xlim(app.UIAxes2, [15 90]);
            end

            % Read the annotator data from an Excel file
            annotator = readtable('Annotator_1.xlsx');

            % Determine which seizure onset pattern to use
            % If the text area value is 0, default to the first pattern, otherwise use the provided value
            num = [];
            if str2double(app.SezireOnsetPatternTextArea_2.Value) == 0
                num = 1;
            else
                num = str2double(app.SezireOnsetPatternTextArea_2.Value);
            end

            % Extract the seizure list from the annotator table
            s_list = table2array(annotator(:, 2:3));
            s_a = s_list{num, 1};  % Get the seizure A identifier
            s_b = s_list{num, 2};  % Get the seizure B identifier

            % Determine the image sources based on the slider value and update the GUI images
            if slider_val <= 0
                % If the slider value is less than or equal to 0, use the initial images
                app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_top.jpg'];
                app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_top.jpg'];
                app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_side.jpg'];
                app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_side.jpg'];
                app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_left.jpg'];
                app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_left.jpg'];
                app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_right.jpg'];
                app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_right.jpg'];
            else
                % If the slider value is greater than 0, use the corresponding images for that value
                app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_top.jpg'];
                app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_top.jpg'];
                app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_side.jpg'];
                app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_side.jpg'];
                app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_left.jpg'];
                app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_left.jpg'];
                app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_right.jpg'];
                app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_right.jpg'];
            end
            % Uncomment the following line to export the app's UI figure as an image
            % exportapp(app.UIFigure, 'AppImage.png', 'Resolution', 300)
        end

        % Button pushed function: PLOTButton
        function PLOTButtonPushed(app, event)

            % Define the path for the GUI files
            % =============================================================
            % Dynamic path based on the current file location
            path_GUI = [fileparts(fileparts(mfilename('fullpath'))) '\'];
            % =============================================================

            % Set the title and default button value in the GUI
            app.AretheseizuressimilarButtonGroup.Title = 'Are the seizures similar?';
            app.ChooseanoptionButton.Value = true;

            % Add GUI-related paths to MATLAB search path
            addpath(genpath([path_GUI 'GUI\']));
            app.ChooseanoptionButton.Value = true;

            % Read seizure annotations from an Excel file
            annotator = readtable('Annotator_1.xlsx');

            % Determine the selected seizure number from the GUI input
            num = [];
            if str2double(app.SezireOnsetPatternTextArea_2.Value) == 0
                num = 1;
            else
                num = str2double(app.SezireOnsetPatternTextArea_2.Value);
            end
            app.SezireOnsetPatternTextArea_2.Value = num2str(num);

            % Extract seizure identifiers from the annotation table
            s_list = table2array(annotator(:, 2:3));
            s_a = s_list{num, 1};
            s_b = s_list{num, 2};

            % Load feature set data
            data = importdata('feature_set.mat');
            fs = 200; % Sampling frequency

            % Find indices for the selected seizures in the data
            s_a_index = find(strcmp(['P' s_a], data(:, 1)) == 1);
            s_b_index = find(strcmp(['P' s_b], data(:, 1)) == 1);

            %% Display seizure onset patterns
            onset_lib = importdata('onset_lib.mat');
            if ~strcmp(data{s_a_index, 4}, 'NR')
                app.OnsetPatternTextArea.Value = string(onset_lib(str2double(data{s_a_index, 4})));
            else
                app.OnsetPatternTextArea.Value = 'Not available';
            end

            if ~strcmp(data{s_b_index, 4}, 'NR')
                app.OnsetPatternTextArea_2.Value = string(onset_lib(str2double(data{s_b_index, 4})));
            else
                app.OnsetPatternTextArea_2.Value = 'Not available';
            end

            % Display seizure durations
            app.SeizureDurationTextArea.Value = [num2str(data{s_a_index, 3}) ' s'];
            app.SeizureDurationTextArea_2.Value = [num2str(data{s_b_index, 3}) ' s'];

            %% Plot seizure onset region list for seizure A
            app.SeizuretimesSlider.Value = -15;
            slider_val = round(app.SeizuretimesSlider.Value);

            % Load data for seizure A
            data_a = importdata([path_GUI 'GUI\Data clips\P' s_a '.mat']);
            data_a = sortrows(data_a, 1);

            % Extract unique region names for seizure A
            reg_name_a = data_a(:, 4);
            reg_name_a_unique = unique(reg_name_a, 'stable');

            % Remove irrelevant region names
            str_list = {'Outside of the brain', 'White matter', 'Invalid SEEG Bipolar Montage'};
            for temp_no = 1:length(str_list)
                reg_name_a_unique(find(strcmp(reg_name_a_unique, str_list{temp_no}) == 1)) = [];
            end

            % Collect one channel per region for seizure A
            data_store_a = [];
            start_a = [];
            stop_a = [];
            for temp_no = 1:length(reg_name_a_unique)
                ch_index = find(strcmp(reg_name_a, reg_name_a_unique{temp_no}) == 1);
                start_temp = cell2mat(data_a(ch_index, 2));
                stop_temp = cell2mat(data_a(ch_index, 3));
                [val, start_index] = min(start_temp);

                temp = data_a{ch_index(start_index), 5};
                temp = temp / (1.05 * max(temp));
                data_store_a(temp_no, :) = temp;
                start_a(temp_no) = val;
                stop_a(temp_no) = stop_temp(start_index);
            end

            % Adjust start and stop times based on onset
            [start_a_onset, start_a_index] = min(start_a);
            start_a = start_a - start_a_onset;
            stop_a = stop_a - start_a_onset;

            % Limit data length to 100 seconds
            data_store_a = data_store_a(:, 1:100 * fs);

            % Ensure at least 10 channels are present by padding with zeros
            add_zero = ceil((10 - length(start_a)) / 2);
            for temp_no = 1:add_zero
                stop_a(length(start_a) + 1) = 1000;
                data_store_a(length(start_a) + 1, :) = zeros(1, 20000) / 0;
                reg_name_a_unique{length(start_a) + 1} = '';
                start_a(length(start_a) + 1) = 1000;
            end

            % Clear the current plot and plot seizure A data
            cla(app.UIAxes)
            for ch_no = 1:length(start_a)
                temp_name = regexprep(reg_name_a_unique{ch_no}, '\s+', ' ');
                text(app.UIAxes, -15.5, length(start_a) - ch_no + 1, temp_name, 'HorizontalAlignment', 'right');
                hold(app.UIAxes, 'on')
                plot(app.UIAxes, -15 + (1:100 * 200) / fs, -data_store_a(ch_no, 1:100 * fs) + length(start_a) - ch_no + 1, 'k', 'LineWidth', 0.1);
                scatter(app.UIAxes, start_a(ch_no), length(start_a) - ch_no + 1, 30, 'r', 'filled');
                scatter(app.UIAxes, stop_a(ch_no), length(stop_a) - ch_no + 1, 30, 'b', 'filled');
            end

            % Set plot properties for seizure A
            yticks(app.UIAxes, []);
            ylim(app.UIAxes, [-1.5 12]);
            xlim(app.UIAxes, [-31 44]);
            xlabel(app.UIAxes, 'Time (s)');
            ylabel(app.UIAxes, '');
            title(app.UIAxes, '');

            % Plot time indicator for seizure A
            plot_time = -1 * ones(1, 116);
            plot(app.UIAxes, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
            plot_time = nan(1, 116);
            plot_time(slider_val + 16) = -1;
            plot(app.UIAxes, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

            %% Plot seizure onset region list for seizure B
            % Load data for seizure B
            data_b = importdata([path_GUI 'GUI\Data clips\P' s_b '.mat']);
            data_b = sortrows(data_b, 1);

            % Extract unique region names for seizure B
            reg_name_b = data_b(:, 4);
            reg_name_b_unique = unique(reg_name_b, 'stable');

            % Remove irrelevant region names
            for temp_no = 1:length(str_list)
                reg_name_b_unique(find(strcmp(reg_name_b_unique, str_list{temp_no}) == 1)) = [];
            end

            % Collect one channel per region for seizure B
            data_store_b = [];
            start_b = [];
            stop_b = [];
            for temp_no = 1:length(reg_name_b_unique)
                ch_index = find(strcmp(reg_name_b, reg_name_b_unique{temp_no}) == 1);
                start_temp = cell2mat(data_b(ch_index, 2));
                stop_temp = cell2mat(data_b(ch_index, 3));
                [val, start_index] = min(start_temp);

                temp = data_b{ch_index(start_index), 5};
                temp = temp / (1.05 * max(temp));
                data_store_b(temp_no, :) = temp;
                start_b(temp_no) = val;
                stop_b(temp_no) = stop_temp(start_index);
            end

            % Adjust start and stop times based on onset
            [start_b_onset, start_b_index] = min(start_b);
            start_b = start_b - start_b_onset;
            stop_b = stop_b - start_b_onset;

            % Limit data length to 100 seconds
            data_store_b = data_store_b(:, 1:100 * fs);

            % Ensure at least 10 channels are present by padding with zeros
            add_zero = ceil((10 - length(start_b)) / 2);
            for temp_no = 1:add_zero
                stop_b(length(start_b) + 1) = 1000;
                data_store_b(length(start_b) + 1, :) = zeros(1, 20000) / 0;
                reg_name_b_unique{length(start_b) + 1} = '';
                start_b(length(start_b) + 1) = 1000;
            end

            % Clear the current plot and plot seizure B data
            cla(app.UIAxes2)
            for ch_no = 1:length(stop_b)
                temp_name = regexprep(reg_name_b_unique{ch_no}, '\s+', ' ');
                text(app.UIAxes2, -15.5, length(start_b) - ch_no + 1, temp_name, 'HorizontalAlignment', 'right');
                hold(app.UIAxes2, 'on')
                plot(app.UIAxes2, -15 + (1:100 * 200) / fs, -data_store_b(ch_no, 1:100 * fs) + length(start_b) - ch_no + 1, 'k', 'LineWidth', 0.1);
                scatter(app.UIAxes2, start_b(ch_no), length(start_b) - ch_no + 1, 30, 'r', 'filled');
                scatter(app.UIAxes2, stop_b(ch_no), length(stop_b) - ch_no + 1, 30, 'b', 'filled');
            end

            % Set plot properties for seizure B
            yticks(app.UIAxes2, []);
            ylim(app.UIAxes2, [-1.5 12]);
            xlim(app.UIAxes2, [-31 44]);
            xlabel(app.UIAxes2, 'Time (s)');
            ylabel(app.UIAxes2, '');
            title(app.UIAxes2, '');

            % Plot time indicator for seizure B
            plot_time = -1 * ones(1, 116);
            plot(app.UIAxes2, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
            plot_time = nan(1, 116);
            plot_time(slider_val + 16) = -1;
            plot(app.UIAxes2, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

            %% Update image display based on slider value
            if slider_val <= 0
                % Display initial images for both seizures
                app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_0_top.jpg'];
                app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_0_top.jpg'];

                app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_0_side.jpg'];
                app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_0_side.jpg'];

                app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_0_left.jpg'];
                app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_0_left.jpg'];

                app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_0_right.jpg'];
                app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_0_right.jpg'];
            else
                % Display images based on the current slider value for both seizures
                app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_top.jpg'];
                app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_top.jpg'];

                app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_side.jpg'];
                app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_side.jpg'];

                app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_left.jpg'];
                app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_left.jpg'];

                app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_right.jpg'];
                app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_right.jpg'];
            end
        end


       
  % Button pushed function: NEXTButton
function NEXTButtonPushed(app, event)

    % ENTER PATH FOR THE GUI
    % =============================================================
    %path_GUI='D:\Project_2\Codes\Codes Final\';
    path_GUI=[fileparts(fileparts(mfilename('fullpath'))) '\'];
    % =============================================================

    % Set the title of the button group for seizure similarity
    app.AretheseizuressimilarButtonGroup.Title = 'Are the seizures similar?';
    selectedButton = app.AretheseizuressimilarButtonGroup.SelectedObject;

    % Add path for the GUI
    addpath(genpath([path_GUI 'GUI\']));

    % Read the annotator data from an Excel file
    annotator = readtable('Annotator_1.xlsx');
    
    % Check if the option is selected
    if strcmp(selectedButton.Text, 'Choose an option') ~= 1

        % Initialize seizure number
        num = [];
        if str2double(app.SezireOnsetPatternTextArea_2.Value) == 0
            num = 1;
        else
            num = str2double(app.SezireOnsetPatternTextArea_2.Value);

            % Select seizures from the list
            s_list = table2array(annotator(:, 2:3));
            s_a = s_list{num, 1};
            s_b = s_list{num, 2};

            % Store the results
            store = [];
            store{1} = num2str(num);
            store{2} = ['P' s_a];
            store{3} = ['P' s_b];
            store{4} = selectedButton.Text;

            % Write the results in an Excel sheet
            store_table = cell2table(store);
            writetable(store_table, 'Results_Annotator_1.xlsx', 'Sheet', 1, 'Range', ['A' num2str(2*num+1) ':' 'D' num2str(2*num+2)]);

            % Reset the option button and increment the seizure number
            app.ChooseanoptionButton.Value = true;
            num = num + 1;
        end

        % Update the option button value
        app.ChooseanoptionButton.Value = true;

        % Update the seizure onset pattern text area
        app.SezireOnsetPatternTextArea_2.Value = num2str(num);

        % Select the seizures from the list again
        s_list = table2array(annotator(:, 2:3));
        s_a = s_list{num, 1};
        s_b = s_list{num, 2};

        % Load data
        data = importdata('feature_set.mat');
        fs = 200;

        % Find indices for the selected seizures
        s_a_index = find(strcmp(['P' s_a], data(:, 1)) == 1);
        s_b_index = find(strcmp(['P' s_b], data(:, 1)) == 1);

        %% Show duration and onset pattern
        onset_lib = importdata('onset_lib.mat');
        
        % Update onset pattern for seizure A
        if ~strcmp(data{s_a_index, 4}, 'NR')
            app.OnsetPatternTextArea.Value = string(onset_lib(str2double(data{s_a_index, 4})));
        else
            app.OnsetPatternTextArea.Value = ['Not available'];
        end

        % Update onset pattern for seizure B
        if ~strcmp(data{s_b_index, 4}, 'NR')
            app.OnsetPatternTextArea_2.Value = string(onset_lib(str2double(data{s_b_index, 4})));
        else
            app.OnsetPatternTextArea_2.Value = ['Not available'];
        end

        % Update seizure duration for both seizures
        app.SeizureDurationTextArea.Value = [num2str(data{s_a_index, 3}) ' s'];
        app.SeizureDurationTextArea_2.Value = [num2str(data{s_b_index, 3}) ' s'];

        %% Plot seizure onset region list for seizure A
        app.SeizuretimesSlider.Value = -15;
        slider_val = round(app.SeizuretimesSlider.Value);

        % Load data for seizure A
        data_a = importdata([path_GUI 'GUI\Data clips\P' s_a '.mat']);
        data_a = sortrows(data_a, 1);

        reg_name_a = data_a(:, 4);
        reg_name_a_unique = unique(reg_name_a, 'stable');

        % Exclude specific regions
        str_list = {'Outside of the brain'; 'White matter'; 'Invalid SEEG Bipolar Montage'};
        for temp_no = 1:length(str_list)
            reg_name_a_unique(find(strcmp(reg_name_a_unique, str_list{temp_no}) == 1)) = [];
        end

        % Collect one channel per region
        data_store_a = [];
        start_a = [];
        stop_a = [];
        for temp_no = 1:length(reg_name_a_unique)
            ch_index = find(strcmp(reg_name_a, reg_name_a_unique{temp_no}) == 1);
            start_temp = cell2mat(data_a(ch_index, 2));
            stop_temp = cell2mat(data_a(ch_index, 3));
            [val, start_index] = min(start_temp);

            temp = data_a{ch_index(start_index), 5};
            temp = temp / (1.05 * max(temp));
            data_store_a(temp_no, :) = temp;
            clear temp
            start_a(temp_no) = val;
            stop_a(temp_no) = stop_temp(start_index);
            clear start_temp stop_temp ch_index start_index val
        end

        % Adjust start and stop times for seizure A
        [start_a_onset, start_a_index] = min(start_a);
        start_a = start_a - start_a_onset;
        stop_a = stop_a - start_a_onset;

        data_store_a = data_store_a(:, 1:100*fs);

        % Add zero padding if necessary
        add_zero = ceil((10 - length(start_a)) / 2);
        for temp_no = 1:add_zero
            stop_a(length(start_a) + 1) = 1000;
            data_store_a(length(start_a) + 1, :) = zeros(1, 20000) / 0;
            reg_name_a_unique{length(start_a) + 1} = '';
            start_a(length(start_a) + 1) = 1000;
        end

        % Plot data for seizure A
        cla(app.UIAxes)
        for ch_no = 1:length(start_a)
            temp_name = regexprep(reg_name_a_unique{ch_no}, '\s+', ' ');
            text(app.UIAxes, -15.5, length(start_a) - ch_no + 1, temp_name, 'HorizontalAlignment', 'right');
            hold(app.UIAxes, 'on')
            plot(app.UIAxes, -15 + (1:100*200) / fs, -data_store_a(ch_no, 1:100*fs) + length(start_a) - ch_no + 1, 'k', 'LineWidth', 0.1);
            scatter(app.UIAxes, start_a(ch_no), length(start_a) - ch_no + 1, 30, 'r', 'filled');
            scatter(app.UIAxes, stop_a(ch_no), length(stop_a) - ch_no + 1, 30, 'b', 'filled');
        end

        % Set plot properties for seizure A
        yticks(app.UIAxes, []);
        ylim(app.UIAxes, [-1.5 12]);
        xlim(app.UIAxes, [-31 44]);
        xlabel(app.UIAxes, 'Time (s)');
        ylabel(app.UIAxes, '');
        title(app.UIAxes, '');

        % Plot time indicator for seizure A
        plot_time = -1 * ones(1, 116);
        plot(app.UIAxes, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
        plot_time = nan(1, 116);
        plot_time(slider_val + 16) = -1;
        plot(app.UIAxes, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

        %% Plot seizure onset region list for seizure B

        % Load data for seizure B
        data_b = importdata([path_GUI 'GUI\Data clips\P' s_b '.mat']);
        data_b = sortrows(data_b, 1);

        reg_name_b = data_b(:, 4);
        reg_name_b_unique = unique(reg_name_b, 'stable');

        % Exclude specific regions
        for temp_no = 1:length(str_list)
            reg_name_b_unique(find(strcmp(reg_name_b_unique, str_list{temp_no}) == 1)) = [];
        end

        % Collect one channel per region
        data_store_b = [];
        start_b = [];
        stop_b = [];
        for temp_no = 1:length(reg_name_b_unique)
            ch_index = find(strcmp(reg_name_b, reg_name_b_unique{temp_no}) == 1);
            start_temp = cell2mat(data_b(ch_index, 2));
            stop_temp = cell2mat(data_b(ch_index, 3));
            [val, start_index] = min(start_temp);

            temp = data_b{ch_index(start_index), 5};
            temp = temp / (1.05 * max(temp));
            data_store_b(temp_no, :) = temp;
            clear temp
            start_b(temp_no) = val;
            stop_b(temp_no) = stop_temp(start_index);
            clear start_temp stop_temp ch_index start_index val
        end

        % Adjust start and stop times for seizure B
        [start_b_onset, start_b_index] = min(start_b);
        start_b = start_b - start_b_onset;
        stop_b = stop_b - start_b_onset;

        data_store_b = data_store_b(:, 1:100*fs);

        % Add zero padding if necessary
        add_zero = ceil((10 - length(start_b)) / 2);
        for temp_no = 1:add_zero
            stop_b(length(start_b) + 1) = 1000;
            data_store_b(length(start_b) + 1, :) = zeros(1, 20000) / 0;
            reg_name_b_unique{length(start_b) + 1} = '';
            start_b(length(start_b) + 1) = 1000;
        end

        % Plot data for seizure B
        cla(app.UIAxes2)
        for ch_no = 1:length(stop_b)
            temp_name = regexprep(reg_name_b_unique{ch_no}, '\s+', ' ');
            text(app.UIAxes2, -15.5, length(start_b) - ch_no + 1, temp_name, 'HorizontalAlignment', 'right');
            hold(app.UIAxes2, 'on')
            plot(app.UIAxes2, -15 + (1:100*200) / fs, -data_store_b(ch_no, 1:100*fs) + length(start_b) - ch_no + 1, 'k', 'LineWidth', 0.1);
            scatter(app.UIAxes2, start_b(ch_no), length(start_b) - ch_no + 1, 30, 'r', 'filled');
            scatter(app.UIAxes2, stop_b(ch_no), length(stop_b) - ch_no + 1, 30, 'b', 'filled');
        end

        % Set plot properties for seizure B
        yticks(app.UIAxes2, []);
        ylim(app.UIAxes2, [-1.5 12]);
        xlim(app.UIAxes2, [-31 44]);
        xlabel(app.UIAxes2, 'Time (s)');
        ylabel(app.UIAxes2, '');
        title(app.UIAxes2, '');

        % Plot time indicator for seizure B
        plot_time = -1 * ones(1, 116);
        plot(app.UIAxes2, -15:100, plot_time, 'w^', 'MarkerFaceColor', 'w');
        plot_time = nan(1, 116);
        plot_time(slider_val + 16) = -1;
        plot(app.UIAxes2, -15:100, plot_time, 'k^', 'MarkerFaceColor', 'k');

        %% Load and display images based on slider value
        if (slider_val <= 0)
            app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_top.jpg'];
            app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_top.jpg'];

            app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_side.jpg'];
            app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_side.jpg'];

            app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_left.jpg'];
            app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_left.jpg'];

            app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(0) '_right.jpg'];
            app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(0) '_right.jpg'];

        else
            app.Image.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_top.jpg'];
            app.Image_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_top.jpg'];

            app.Image2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_side.jpg'];
            app.Image2_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_side.jpg'];

            app.Image3.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_left.jpg'];
            app.Image3_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_left.jpg'];

            app.Image4.ImageSource = [path_GUI 'GUI\Slides Images\P' s_a '_' num2str(slider_val) '_right.jpg'];
            app.Image4_2.ImageSource = [path_GUI 'GUI\Slides Images\P' s_b '_' num2str(slider_val) '_right.jpg'];
        end

    else
        % Show error message if no option is selected
        app.AretheseizuressimilarButtonGroup.Title = 'Please choose an option';
    end
end


end

% Component initialization
methods (Access = private)

    % Create UIFigure and components
    function createComponents(app)

        % Create UIFigure and hide until all components are created
        app.UIFigure = uifigure('Visible', 'off');
        app.UIFigure.Position = [100 100 1327 773];
        app.UIFigure.Name = 'MATLAB App';

        % Create GridLayout3
        app.GridLayout3 = uigridlayout(app.UIFigure);
        app.GridLayout3.ColumnWidth = {'1.02x', '2x', '0.75x'};
        app.GridLayout3.RowHeight = {'14.48x', '5x', '14.48x'};
        app.GridLayout3.RowSpacing = 0;
        app.GridLayout3.Padding = [10 0 10 0];

        % Create SeizureBPanel
        app.SeizureBPanel = uipanel(app.GridLayout3);
        app.SeizureBPanel.Title = 'Seizure B';
        app.SeizureBPanel.Layout.Row = 3;
        app.SeizureBPanel.Layout.Column = 1;
        app.SeizureBPanel.FontSize = 14;

        % Create GridLayout_2
        app.GridLayout_2 = uigridlayout(app.SeizureBPanel);

        % Create Image_2
        app.Image_2 = uiimage(app.GridLayout_2);
        app.Image_2.Layout.Row = 1;
        app.Image_2.Layout.Column = 1;

        % Create Image2_2
        app.Image2_2 = uiimage(app.GridLayout_2);
        app.Image2_2.Layout.Row = 1;
        app.Image2_2.Layout.Column = 2;

        % Create Image3_2
        app.Image3_2 = uiimage(app.GridLayout_2);
        app.Image3_2.Layout.Row = 2;
        app.Image3_2.Layout.Column = 1;

        % Create Image4_2
        app.Image4_2 = uiimage(app.GridLayout_2);
        app.Image4_2.Layout.Row = 2;
        app.Image4_2.Layout.Column = 2;

        % Create Panel_2
        app.Panel_2 = uipanel(app.GridLayout3);
        app.Panel_2.Layout.Row = 2;
        app.Panel_2.Layout.Column = 1;

        % Create GridLayout2
        app.GridLayout2 = uigridlayout(app.Panel_2);
        app.GridLayout2.ColumnWidth = {'0.6x', '1.2x'};
        app.GridLayout2.RowHeight = {'1x', '2x', '1x'};

        % Create SeizuretimesSliderLabel
        app.SeizuretimesSliderLabel = uilabel(app.GridLayout2);
        app.SeizuretimesSliderLabel.HorizontalAlignment = 'center';
        app.SeizuretimesSliderLabel.FontSize = 15;
        app.SeizuretimesSliderLabel.FontWeight = 'bold';
        app.SeizuretimesSliderLabel.Layout.Row = 2;
        app.SeizuretimesSliderLabel.Layout.Column = 1;
        app.SeizuretimesSliderLabel.Text = 'Seizure time (s)';

        % Create SeizuretimesSlider
        app.SeizuretimesSlider = uislider(app.GridLayout2);
        app.SeizuretimesSlider.Limits = [-15 85];
        app.SeizuretimesSlider.MajorTicks = [-15 0 15 30 45 60 75];
        app.SeizuretimesSlider.ValueChangedFcn = createCallbackFcn(app, @SeizuretimesSliderValueChanged, true);
        app.SeizuretimesSlider.Layout.Row = 2;
        app.SeizuretimesSlider.Layout.Column = 2;
        app.SeizuretimesSlider.Value = 30;

        % Create OnsetPatternTextAreaLabel
        app.OnsetPatternTextAreaLabel = uilabel(app.GridLayout2);
        app.OnsetPatternTextAreaLabel.HorizontalAlignment = 'center';
        app.OnsetPatternTextAreaLabel.Layout.Row = 1;
        app.OnsetPatternTextAreaLabel.Layout.Column = 1;
        app.OnsetPatternTextAreaLabel.Text = 'Onset Pattern';

        % Create OnsetPatternTextArea
        app.OnsetPatternTextArea = uitextarea(app.GridLayout2);
        app.OnsetPatternTextArea.HorizontalAlignment = 'center';
        app.OnsetPatternTextArea.Layout.Row = 1;
        app.OnsetPatternTextArea.Layout.Column = 2;

        % Create OnsetPatternTextArea_2Label
        app.OnsetPatternTextArea_2Label = uilabel(app.GridLayout2);
        app.OnsetPatternTextArea_2Label.HorizontalAlignment = 'center';
        app.OnsetPatternTextArea_2Label.Layout.Row = 3;
        app.OnsetPatternTextArea_2Label.Layout.Column = 1;
        app.OnsetPatternTextArea_2Label.Text = 'Onset Pattern';

        % Create OnsetPatternTextArea_2
        app.OnsetPatternTextArea_2 = uitextarea(app.GridLayout2);
        app.OnsetPatternTextArea_2.HorizontalAlignment = 'center';
        app.OnsetPatternTextArea_2.Layout.Row = 3;
        app.OnsetPatternTextArea_2.Layout.Column = 2;

        % Create SeizureAPanel
        app.SeizureAPanel = uipanel(app.GridLayout3);
        app.SeizureAPanel.Title = 'Seizure A';
        app.SeizureAPanel.Layout.Row = 1;
        app.SeizureAPanel.Layout.Column = 1;
        app.SeizureAPanel.FontSize = 14;

        % Create GridLayout
        app.GridLayout = uigridlayout(app.SeizureAPanel);

        % Create Image
        app.Image = uiimage(app.GridLayout);
        app.Image.Layout.Row = 1;
        app.Image.Layout.Column = 1;

        % Create Image2
        app.Image2 = uiimage(app.GridLayout);
        app.Image2.Layout.Row = 1;
        app.Image2.Layout.Column = 2;

        % Create Image3
        app.Image3 = uiimage(app.GridLayout);
        app.Image3.Layout.Row = 2;
        app.Image3.Layout.Column = 1;

        % Create Image4
        app.Image4 = uiimage(app.GridLayout);
        app.Image4.Layout.Row = 2;
        app.Image4.Layout.Column = 2;

        % Create Panel_3
        app.Panel_3 = uipanel(app.GridLayout3);
        app.Panel_3.Layout.Row = 2;
        app.Panel_3.Layout.Column = [2 3];

        % Create GridLayout4
        app.GridLayout4 = uigridlayout(app.Panel_3);
        app.GridLayout4.ColumnWidth = {'0.6x', '0.5x', '0.5x', '0.6x', '2x'};

        % Create SeizureDurationTextAreaLabel
        app.SeizureDurationTextAreaLabel = uilabel(app.GridLayout4);
        app.SeizureDurationTextAreaLabel.HorizontalAlignment = 'center';
        app.SeizureDurationTextAreaLabel.FontSize = 14;
        app.SeizureDurationTextAreaLabel.Layout.Row = 1;
        app.SeizureDurationTextAreaLabel.Layout.Column = 1;
        app.SeizureDurationTextAreaLabel.Text = 'Seizure Duration';

        % Create SeizureDurationTextArea
        app.SeizureDurationTextArea = uitextarea(app.GridLayout4);
        app.SeizureDurationTextArea.HorizontalAlignment = 'center';
        app.SeizureDurationTextArea.FontSize = 15;
        app.SeizureDurationTextArea.Layout.Row = 1;
        app.SeizureDurationTextArea.Layout.Column = 2;

        % Create SeizureDurationTextArea_2Label
        app.SeizureDurationTextArea_2Label = uilabel(app.GridLayout4);
        app.SeizureDurationTextArea_2Label.HorizontalAlignment = 'center';
        app.SeizureDurationTextArea_2Label.FontSize = 14;
        app.SeizureDurationTextArea_2Label.Layout.Row = 2;
        app.SeizureDurationTextArea_2Label.Layout.Column = 1;
        app.SeizureDurationTextArea_2Label.Text = 'Seizure Duration';

        % Create SeizureDurationTextArea_2
        app.SeizureDurationTextArea_2 = uitextarea(app.GridLayout4);
        app.SeizureDurationTextArea_2.HorizontalAlignment = 'center';
        app.SeizureDurationTextArea_2.FontSize = 15;
        app.SeizureDurationTextArea_2.Layout.Row = 2;
        app.SeizureDurationTextArea_2.Layout.Column = 2;

        % Create SezireOnsetPatternTextArea_2
        app.SezireOnsetPatternTextArea_2 = uitextarea(app.GridLayout4);
        app.SezireOnsetPatternTextArea_2.HorizontalAlignment = 'center';
        app.SezireOnsetPatternTextArea_2.FontSize = 15;
        app.SezireOnsetPatternTextArea_2.FontWeight = 'bold';
        app.SezireOnsetPatternTextArea_2.Layout.Row = 1;
        app.SezireOnsetPatternTextArea_2.Layout.Column = 3;
        app.SezireOnsetPatternTextArea_2.Value='1';

        % Create PLOTButton
        app.PLOTButton = uibutton(app.GridLayout4, 'push');
        app.PLOTButton.ButtonPushedFcn = createCallbackFcn(app, @PLOTButtonPushed, true);
        app.PLOTButton.FontSize = 16;
        app.PLOTButton.Layout.Row = 2;
        app.PLOTButton.Layout.Column = 3;
        app.PLOTButton.Text = 'PLOT';

        % Create NEXTButton
        app.NEXTButton = uibutton(app.GridLayout4, 'push');
        app.NEXTButton.ButtonPushedFcn = createCallbackFcn(app, @NEXTButtonPushed, true);
        app.NEXTButton.FontSize = 18;
        app.NEXTButton.FontWeight = 'bold';
        app.NEXTButton.Layout.Row = [1 2];
        app.NEXTButton.Layout.Column = 4;
        app.NEXTButton.Text = 'NEXT';

        % Create AretheseizuressimilarButtonGroup
        app.AretheseizuressimilarButtonGroup = uibuttongroup(app.GridLayout4);
        app.AretheseizuressimilarButtonGroup.TitlePosition = 'centertop';
        app.AretheseizuressimilarButtonGroup.Title = 'Are the seizures similar?';
        app.AretheseizuressimilarButtonGroup.Layout.Row = [1 2];
        app.AretheseizuressimilarButtonGroup.Layout.Column = 5;
        app.AretheseizuressimilarButtonGroup.FontWeight = 'bold';
        app.AretheseizuressimilarButtonGroup.FontSize = 18;

        % Create ChooseanoptionButton
        app.ChooseanoptionButton = uiradiobutton(app.AretheseizuressimilarButtonGroup);
        app.ChooseanoptionButton.Text = 'Choose an option';
        app.ChooseanoptionButton.WordWrap = 'on';
        app.ChooseanoptionButton.Position = [12 2 122 50];
        app.ChooseanoptionButton.Value = true;

        % Create SomewhatsimilarButton
        app.SomewhatsimilarButton = uiradiobutton(app.AretheseizuressimilarButtonGroup);
        app.SomewhatsimilarButton.Text = ' Somewhat similar';
        app.SomewhatsimilarButton.FontSize = 15;
        app.SomewhatsimilarButton.Position = [133 2 145 22];

        % Create VerysimilarButton
        app.VerysimilarButton = uiradiobutton(app.AretheseizuressimilarButtonGroup);
        app.VerysimilarButton.Text = ' Very similar';
        app.VerysimilarButton.FontSize = 15;
        app.VerysimilarButton.Position = [133 30 104 22];

        % Create LowsimilarityButton
        app.LowsimilarityButton = uiradiobutton(app.AretheseizuressimilarButtonGroup);
        app.LowsimilarityButton.Text = ' Low similarity';
        app.LowsimilarityButton.FontSize = 15;
        app.LowsimilarityButton.Position = [290 30 116 22];

        % Create NotrealtedButton
        app.NotrealtedButton = uiradiobutton(app.AretheseizuressimilarButtonGroup);
        app.NotrealtedButton.Text = ' Not related';
        app.NotrealtedButton.FontSize = 15;
        app.NotrealtedButton.Position = [290 2 99 22];

        % Create UIAxes2
        app.UIAxes2 = uiaxes(app.GridLayout3);
        title(app.UIAxes2, 'Title')
        xlabel(app.UIAxes2, 'X')
        ylabel(app.UIAxes2, 'Y')
        zlabel(app.UIAxes2, 'Z')
        app.UIAxes2.Layout.Row = 3;
        app.UIAxes2.Layout.Column = [2 3];

        % Create UIAxes
        app.UIAxes = uiaxes(app.GridLayout3);
        title(app.UIAxes, 'Title')
        xlabel(app.UIAxes, 'X')
        ylabel(app.UIAxes, 'Y')
        zlabel(app.UIAxes, 'Z')
        app.UIAxes.Layout.Row = 1;
        app.UIAxes.Layout.Column = [2 3];

        % Show the figure after all components are created
        app.UIFigure.Visible = 'on';
    end
end

% App creation and deletion
methods (Access = public)

    % Construct app
    function app = GUI

        % Create UIFigure and components
        createComponents(app)

        % Register the app with App Designer
        registerApp(app, app.UIFigure)

        if nargout == 0
            clear app
        end
    end

    % Code that executes before app deletion
    function delete(app)

        % Delete UIFigure when app is deleted
        delete(app.UIFigure)
    end
end
end